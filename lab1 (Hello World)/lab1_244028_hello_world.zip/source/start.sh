#!/bin/bash
java ./server.java
